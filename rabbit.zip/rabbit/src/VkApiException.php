<?php
namespace DigitalStar\vk_api;

use Exception;
use Throwable;

class VkApiException extends Exception {

    public function __construct($message = "", $code = 0, Throwable $previous = null) {
        //echo "\n".$this->__toString()."\n";
        parent::__construct($message, $code, $previous);
    }

    public function __toString() {
        $error = "[Exception]: возникла ошибка:";
        $error .= "\r\n[Exception]: текст: {$this->getMessage()}";
        $error .= "\r\n[Exception]: код ошибки: {$this->getCode()}";
        $error .= "\r\n[Exception]: файл: {$this->getFile()}:{$this->getLine()}";
        $error .= "\r\n[Exception]: путь ошибки: {$this->getTraceAsString()}\r\n";
        
        // Проверяем существование директории 'error' и создаем ее, если не существует
        if (!is_dir('error')) {
            mkdir('error', 0755, true); // Создаем директорию с правами доступа 0755
        }
        
        // Проверяем, удалось ли открыть файл
        $file = fopen('error/error_log' . date('d-m-Y_h') . ".log", 'a');
        if ($file === false) {
            $error .= "\r\n[Exception]: Не удалось открыть файл для записи";
        } else {
            // Записываем ошибку в файл
            fwrite($file, $error);
            fclose($file);
        }
        
        // Возвращаем строку с информацией об ошибке
        return $error;
    }
}
