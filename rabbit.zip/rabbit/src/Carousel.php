<?php

namespace DigitalStar\vk_api;


class Carousel
{

    public array $config;


    protected function __construct( &$config = [] )
    {
        $this->config = &$config;

        if ( empty( $this->config['action'] ) )
            $this->config['action'] = [ 'type' => 'open_photo' ];
    }

    public static function create( &$config = [] )
    {
        return new self( $config );
    }

    public function title( $title )
    {
        $this->config['title'] = $title;

        return $this;
    }

    public function getTitle()
    {
        return $this->config['title'];
    }

    public function description( $description )
    {
        $this->config['description'] = $description;

        return $this;
    }

    public function getDescription()
    {
        return $this->config['description'];
    }

    public function img( $img )
    {
        $this->config['img'] = $img;

        return $this;
    }

    public function getImg()
    {
        return $this->config['img'];
    }

    public function action( $link = '' )
    {
        if ( empty( $link ) )
            $this->config['action'] = [ 'type' => 'open_photo' ];
        else
            $this->config['action'] = [ 'type' => 'open_link', 'link' => $link ];

        return $this;
    }

    public function getAction()
    {
        return $this->config['action']['link'] ?? false;
    }

    public function kbd( $kbd )
    {
        if ( is_string( $kbd ) )
            $kbd = [ $kbd ];
        $this->config['kbd'] = $kbd;

        return $this;
    }

    public function getKbd()
    {
        return $this->config['kbd'];
    }

    public function dump()
    {
        return $this->config;
    }

    public function load( $config )
    {
        $this->config = $config;

        return $this;
    }

}
