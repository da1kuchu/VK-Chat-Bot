<?php

namespace DigitalStar\vk_api;


$path_dir = __DIR__ . '/src';

require_once( $path_dir . '/Base.php' );
require_once( $path_dir . '/Message.php' );
require_once( $path_dir . '/Carousel.php' );
require_once( $path_dir . '/Post.php' );
require_once( $path_dir . '/vk_api.php' );
require_once( $path_dir . '/VkApiException.php' );
require_once( $path_dir . '/Auth.php' );
require_once( $path_dir . '/Group.php' );
require_once( $path_dir . '/LongPoll.php' );
require_once( $path_dir . '/Coin.php' );
require_once( $path_dir . '/Execute.php' );
require_once( $path_dir . '/SiteAuth.php' );
require_once( $path_dir . '/Diagnostics.php' );
