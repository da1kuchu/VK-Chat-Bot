<?php

const VK_KEY = "токен";
const CONFIRM_STR = "уникальный_ключ";
const VERSION = "5.131";

const RCON_HOST = "адрес";
const RCON_PORT = "порт";
const RCON_PASSWORD = "пароль_rcon";

$admins = ["айди_беседы"];
$super = ["айди"];

// запрещенные команды на сервере
$commands = [
    "op", "stop", "reload", "groups", "deop", "whitelist", "weather", "wl", "givedc", "ms", "mp", "makeserver",
    "makeplugin", "dumpmemory", "plugins", "ep", "extractphar", "extractplugin", "rg", "tc", "tcdel", 
    "timings", "transfer", "transferserver", "usys", "item", "particle", "about", "save-on", "save-off", 
    "save-all", "seed", "sendmessage", "sm", "smsg", "setblock", "setchatformat", "setdisplayname", 
    "setlang", "setnametag", "setspawn", "setworldspawn", "summon", "spawnpoint", "defaultgamemode", 
    "difficulty", "fill", "fperms", "give", "help", "loadplugin", "lvdat", "xp", "cave", "checkperm", 
    "chunkinfo", "ver", "version", "bc", "biome", "broadcaster", "npc", "npc2", "me", "takemoney", 
    "givemoney", "setgroup", "givekey", "delwarp", "setwarp", "ungroup"
];

?>