<?php

require_once "simplevk-master/autoload.php";
require_once "Rcon.php";
require_once "Config.php";

use DigitalStar\vk_api\vk_api;
use Thedudeguy\Rcon;

function isSuperUser($user_id) {
    global $super;
    return in_array($user_id, $super);
}

function isCommandAllowed($command, $user_id) {
    global $commands;
    
    if (in_array($command, $commands)) {
        return isSuperUser($user_id);
    }
    
    return true;
}

$blacklistFile = 'block.json';

function loadBlacklist() {
    global $blacklistFile;
    if (file_exists($blacklistFile)) {
        $data = file_get_contents($blacklistFile);
        return json_decode($data, true);
    }
    return [];
}

function saveBlacklist($blacklist) {
    global $blacklistFile;
    file_put_contents($blacklistFile, json_encode($blacklist));
}

function addToBlacklist($user_id) {
    $blacklist = loadBlacklist();
    if (!in_array($user_id, $blacklist)) {
        $blacklist[] = $user_id;
        saveBlacklist($blacklist);
    }
}

function isBlacklisted($user_id) {
    $blacklist = loadBlacklist();
    return in_array($user_id, $blacklist);
}

$vk = vk_api::create(VK_KEY, VERSION)->setConfirm(CONFIRM_STR);
$vk->initVars($id, $message, $payload, $user_id, $type);

if ($type == "message_new") {
    if (isBlacklisted($user_id)) {
        $vk->reply("Вы не можете вводить команды, так как вы находитесь в черном списке RCON.");
        exit;
    }

    if (in_array($id, $admins)) {
        if ($message[0] == "/") {
            $message = strtolower(trim(ltrim($message, "/")));
            $command = explode(" ", $message)[0];

            if (!in_array($command, $commands) && strpos($message, "$") === false && !isSuperUser($id)) {
                if (isCommandAllowed($command, $user_id)) {
                    try {
                        $rcon = new Rcon(RCON_HOST, RCON_PORT, RCON_PASSWORD, 1);
                        if ($rcon->connect()) {
                            $response = trim($rcon->sendCommand($message));
                            if ($response !== "") {
                                $response = "\n\n" . $response;
                            }
                            $response = str_replace(
                                ["§a", "§e", "§l", "§r", "§b", "§d", "§c", "§4", "§1", "§9", "§f", "§6", "§8", "§2", "§7"],
                                "",
                                $response
                            );

                            $vk->reply(trim("%a_full%, Команда успешно отправлена на сервер! " . $response));
                        } else {
                            $vk->reply("%a_full%, Отсутствует подключение к RCON! Ожидайте подключения.");
                        }
                    } catch (Exception $e) {
                        $vk->reply("%a_full%, \n\n" . $e->getMessage());
                    }
                } else {
                    $vk->reply("%a_full%, Эту команду нельзя использовать!");
                }
            } else {
                $vk->reply("%a_full%, Эта команда не разрешена или содержит запрещенное слово.");
            }
        } elseif ($message[0] == "!") {
            $message = strtolower(trim(ltrim($message, "!")));
            $command = explode(" ", $message)[0];

            switch ($command) {
                case "block":
                    if (isSuperUser($user_id)) {
                        $mentionedUser = trim(explode(" ", $message)[1]);
                        if (!empty($mentionedUser) && is_numeric($mentionedUser)) {
                            addToBlacklist($mentionedUser);
                            $vk->reply("✅ Пользователь [id$mentionedUser|id$mentionedUser] был добавлен в черный список RCON.");
                        } else {
                            $vk->reply("❌ Укажите правильный цифровой ID пользователя для добавления в черный список.");
                        }
                    } else {
                        $vk->reply("❌ Недостаточно прав для выполнения этой команды!");
}
                    break;

                case "панель":
                  if (isSuperUser($user_id)) {
                    $btn_1 = $vk->buttonText('Состояние сервера', 'red', ['command' => 'status']);
                    $btn_2 = $vk->buttonText('Мониторинг сервера', 'green', ['command' => 'list']);
                    $vk->sendButton($id, "💻 Админ панель:",
[
[$btn_1],
[$btn_2]], true);
        } else {
        $vk->reply("❌ У вас нет прав на эту команду.");
}
                    break;
            }
        }
    } else {
        $vk->reply("%a_full%, - " . $id);
    }
}

if ($type == "message_new" && isset($payload['command'])) {
    switch ($payload['command']) {
        case "status":
            if (isSuperUser($user_id)) {
                try {
                    $rcon = new Rcon("45.93.200.203", 19132, "candles", 1);
                    if ($rcon->connect()) {
                        $response = trim($rcon->sendCommand("status"));
                        if ($response !== "") {
                            $response = "\n\n" . $response;
                        }
                        $vk->reply("» Статистика сервера: " . $response . " ");
                    } else {
                        $vk->reply("» Ошибка подключения к серверу!");
                    }
                } catch (Exception $e) {
                    $vk->reply("Произошла неизвестная ошибка...");
                }
            } else {
                $vk->reply("❌ У вас недостаточно прав на такое выполнение");
            }
            break;

        case "list":
            if (isSuperUser($user_id)) {
                try {
                    $rcon = new Rcon("45.93.200.203", 19132, "candles", 1);
                    if ($rcon->connect()) {
                        $response = trim($rcon->sendCommand("list"));
                        if ($response !== "") {
                            $response = "\n\n" . $response;
                        }
                        $vk->reply("» Мониторинг сервера: " . $response . " ");
                    } else {
                        $vk->reply("» Ошибка подключения к серверу!");
                    }
                } catch (Exception $e) {
                    $vk->reply("Произошла неизвестная ошибка...");
                }
            } else {
                $vk->reply("❌ У вас недостаточно прав на такое выполнение.");
            }
            break;
    }
}

?>